package fr.quanteam.bnp;

import java.util.ArrayList;
import java.util.List;

public class BigInt {
	
	
	private List<Byte> array = new ArrayList<>();
	private boolean sign = true; // true is positive and false is negative
	
	public BigInt(String number) throws NumberFormatException
	{
		int littleIndex = 1;
		if(number.charAt(0)== '-')
				this.sign = false;
		else if(number.charAt(0) == '+')
			this.sign = true;
		else
			littleIndex = 0;
		
		for(int i =number.length() -1; i>=littleIndex ; i--)// little endian arrangement
		{
			if(number.charAt(i)>= 48 && number.charAt(i)<=57)
			{
				array.add(number.length() - i -1, (byte) (number.charAt(i)-48));
				
			}
			else
				throw new NumberFormatException();
		}
		
		
	}
	
	public BigInt(Integer number)
	{		
		if(number < 0)
			sign = false;
		else 
			sign = true;
		int result;
		
		if(number < 0)
			result = number * -1;
		else
			result = number;
		
		int rest = result % 10;
		result /= 10;
		array.add((byte)rest);
		while(result > 0 )
		{
			rest = result% 10;
			array.add((byte)rest);
			result/=10;
			
		}
		
	}
	
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if(obj.getClass().getTypeName() != this.getClass().getTypeName())
			return false;
		BigInt ob  = (BigInt)obj;
		if(ob.sign != this.sign || ob.array.size()!= this.array.size())
			return false;
		for(int i=0; i < array.size(); i++)
		{
			if( array.get(0) != ob.array.get(0))
				return false;
		}
		
		return true;
	}
	
	@Override
	public String toString() {
		String result = "";
		if(!sign)
			result+='-';
		for(int i = array.size()-1; i >= 0; i --)
			result+=array.get(i);
		
		return result;
	}

	public List<Byte> getArray() {
		return array;
	}

	public boolean isSign() {
		return sign;
	}
	
	
	
	public void setSign(boolean sign) {
		this.sign = sign;
	}

	public BigInt add(BigInt number)
	{
		BigInt result = new BigInt(0);
		
		Byte carry = 0;
		int index =0;
		Byte  isBigger = (byte)this.compareAbs( number);
		BigInt big, small;
		if(isBigger > 0)
		{
			big = this; small = number;
		}
		else if (isBigger <0)
		{
			big = number; small = this;
			
		}
		else {
			return result;
		}
		
		if(this.sign != number.isSign()) //substraction
		{ 
			
			while(index < small.getArray().size())
			{
				if(big.getArray().get(index)-small.getArray().get(index)+ carry<0)
				{
					result.getArray().add(index, (byte) 
							(10+big.getArray().get(index)-(small.getArray().get(index)+carry)));
					carry =1;
				}
				else
				{
					result.getArray().add(index, (byte) 
							(big.getArray().get(index)-(small.getArray().get(index)+carry)));
					carry = 0;
				}
				
				index ++;
				
			}
			while(index < big.getArray().size())
			{
				if(big.getArray().get(index)- carry<0)
				{
					result.getArray().add(index, (byte) 
							(10+big.getArray().get(index)-carry));
					carry =1;
				}
				else
				{
					result.getArray().add(index, (byte) 
							(big.getArray().get(index)-carry));
					carry = 0;
				}
				
				index ++;
			}
			
			result.setSign(big.isSign());
			return result;
		}
		else 
		{ //simple addition
			while(index < small.getArray().size())
			{
				if(big.getArray().get(index)+small.getArray().get(index)+ carry>=10)
				{
							
					result.getArray().add(index, (byte) 
							((big.getArray().get(index)+small.getArray().get(index)+carry)%10));
					carry = (byte) ((big.getArray().get(index)+small.getArray().get(index)+ carry)/10);
				}
				else
				{
					result.getArray().add(index, (byte) 
							(big.getArray().get(index)+small.getArray().get(index)+carry));
					carry = 0;
				}
				
				index ++;
				
			}
			while(index < big.getArray().size())
			{
				if(big.getArray().get(index)+ carry>=10)
				{				
					result.getArray().add(index, (byte) 
							((big.getArray().get(index)+carry)%10));
					carry = (byte) ((big.getArray().get(index)+small.getArray().get(index)+ carry)/10);
				}
				else
				{
					result.getArray().add(index, (byte) 
							(big.getArray().get(index)+carry));
					carry = 0;
				}
				
				index ++;
			}
			
			if(carry >0)
				result.getArray().add(carry);
			result.setSign(big.isSign());
			return result;
		}
	
	}

	
	private byte compareAbs(BigInt o) {
		if(this.array.size() > o.getArray().size())
			return 1;
		if(this.array.size() < o.getArray().size())
			return -1;
		else
		{
			for (int i = this.getArray().size()-1; i>=0; i--)
			{
				if(this.array.get(i)> o.getArray().get(i))
					return 1;
				if(this.array.get(i)< o.getArray().get(i))
					return -1;
			}
		}
		return 0;
	}
	

}

package fr.quanteam.bnp;

import java.util.ArrayList;
import java.util.List;

public class Permutation {
	
	public static List<String> perm(String s)
	{
		List<String> permList = new ArrayList<>();
		
		permList.add(String.valueOf(s.charAt(0)));
		for(int i = 1; i < s.length(); i++)
		{
			for( int j = permList.size()-1; j >= 0; j--)
			{
				String str = permList.remove(j);
				
				for(int k = 0; k <= str.length(); k++)
				{
					permList.add(str.substring(0,k)+s.charAt(i)+str.substring(k));
				}
			}
		}
		
		return permList;
	}

}

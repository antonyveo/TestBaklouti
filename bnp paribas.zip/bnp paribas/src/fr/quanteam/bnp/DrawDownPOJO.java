package fr.quanteam.bnp;

public class DrawDownPOJO {
	
	int index1=-1;
	int index2=-1;
	double drawDown=0;
	@Override
	public String toString() {
		return "DrawDownPOJO [index1=" + index1 + ", index2=" + index2 + ", drawDown=" + drawDown 
				 + "]";
	}	
	
}

package fr.quanteam.bnp;

import java.util.ArrayList;
import java.util.List;

public class DrawDown {
	
	public static DrawDownPOJO maxDD(List<Double> profits)
	{
		DrawDownPOJO result =  new DrawDownPOJO();
		
		Double max = profits.get(0);
		int maxIndex = 0;
		
		for(int i =1; i< profits.size(); i++)
		{
			if(max < profits.get(i))
			{
				max = profits.get(i);
				maxIndex = i;
			}
			else {
				Double drop = max - profits.get(i);
				if(drop > result.drawDown)
				{
					result.drawDown = drop;
					result.index1 = maxIndex;
					result.index2 = i;
				}
			}
		}
		
		return result;
	}
	
	
	public static List<DrawDownPOJO> listDDs(List<Double> profits)
	{
		List<DrawDownPOJO> results = new ArrayList<>();
		
		Double max = profits.get(0);
		int maxIndex = 0;
		DrawDownPOJO result = new DrawDownPOJO();
		for(int i =1; i< profits.size(); i++)
		{
			if(max < profits.get(i))
			{
				max = profits.get(i);
				maxIndex = i;
				if(result.index1 >=0&&result.index2>=0&& max > profits.get(result.index1))
				{
					results.add(result);
					result = new DrawDownPOJO();
				}
			}
			else {
				
				Double drop = max - profits.get(i);
				if(drop > -1d*result.drawDown)
				{
					result.drawDown = -1d*drop;
					result.index1 = maxIndex;
					result.index2 = i;
				}
			}
		}
		if(result.index1 >=0&&result.index2>=0)
			results.add(result);
		return results;
	}

}

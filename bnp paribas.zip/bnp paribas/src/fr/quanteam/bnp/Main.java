package fr.quanteam.bnp;

import java.util.List;
import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		// Merge sort algo
		System.out.println("-------------------Merge Sort-----------------");
		int array[] = {12,45, 23, 100, 956, 222, 98};
		System.out.print("initial list ");
		for(int i = 0; i < array.length; i++)
			System.out.printf("%d ", array[i]);
		System.out.println("");
		
		MergeSort.sort(array);
		System.out.print("sorted list ");
		for(int i = 0; i < array.length; i++)
			System.out.printf("%d ", array[i]);
		System.out.println("");
		
		// Permutation
		System.out.println("-------------------Permutation-----------------");
		String s = "ABC";
		List<String> l =Permutation.perm(s);
		System.out.println(l);
		
		//Big integers
		System.out.println("-------------------BigIntegers-----------------");
		BigInt  big1 = new BigInt("-650");
		BigInt big2 = new BigInt(150);
		BigInt big3 = big1.add(big2);
		System.out.println("big1="+big1+" big2="+big2);
		System.out.println("sum="+big3.toString());
		
		
		//DrawDown
		System.out.println("-------------------Max DrawDown-----------------");
		Double prts[] = {5d, 10d, 18d, 17d, 12d, 20d, 25d, 18d, 22d, 17d, 14d, 19d, 28d, 22d, 19d};
		
		List<Double> profits = Arrays.asList(prts);
		
		DrawDownPOJO dd= DrawDown.maxDD(profits);
		System.out.println(dd);
		System.out.println("-------------------List of DrawDowns-----------------");
		List<DrawDownPOJO> ddList =DrawDown.listDDs(profits);

		System.out.println(ddList);

	}

}

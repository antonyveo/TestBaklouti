package fr.quanteam.bnp;


public class MergeSort {
	
	
	
	public static void sort(int array[])
	{
		int curr_size;
		int start_pos;
		
		for(curr_size = 1; curr_size <= array.length-1; curr_size = 2*curr_size)
		{
			for(start_pos =0;start_pos < array.length-1; start_pos += 2*curr_size )
			{
				int middle = (start_pos+curr_size-1 < array.length-1)?start_pos+curr_size-1:array.length-1;
				int end = (start_pos+curr_size*2-1 < array.length-1)?start_pos+curr_size*2-1:array.length-1;
				merge(array, start_pos, middle, end);
				
			}
		}
	}
	
	private static void merge(int array[], int begin, int middle, int end)
	{
		int size1 = middle - begin +1, size2= end - middle;
		int array1[] = new int[size1], array2[] = new int[size2];
		
		for(int i =0; i < size1; i++)
			array1[i] =	array[begin+i];
		for(int i= 0; i < size2; i++)
			array2[i]= array[middle + 1 + i];
		
		int i=0, j=0, k = begin;
		
		while (i < size1 && j < size2)
		{
			if(array1[i] < array2[j])
			{
				array[k] = array1[i];
				i++;
			}
			else
			{
				array[k] = array2[j];
				j++;
			}
			
			k++;
		}
		
		
		while( i < size1)
		{
			array[k] = array1[i];
			i++; k++;
		}
		
		while(j < size2)
		{
			array[k] = array2[j];
			k++; j++;
		}
		
	}

}
